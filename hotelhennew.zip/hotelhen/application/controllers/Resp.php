<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Resp extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
	}

    public function call()
    {
        //$view=$_GET['v'];
        $t=$_GET['t'];
        if (!empty($_POST)) {
            foreach ($_POST as $key => $value) {
                $this->db->like($key, $value);

            }
        }
        $t= $this->db->get($t)->result();
        $this->load->view('Resp/filter', ['data'=>$t]);
    }
    public function DataCheck()
    {
       if (!empty($_GET ['ref'])) {
           $car=$_GET['ref'];
           $this->db->where('RefPB', $car);
           $this->db->select('*');
           $this->db->from('pemesanan');
           $this->db->join('tipe_room', 'Tipe_room.id =
           pemesanan.id_kamar');

           $yourbooked = $this->db->get()->result();
           $data['booklah']=$yourbooked;
           $data['id']=$car;
          // var_dump($data); die;
          $this->load->view('Resp/Ref', ['data'=>$data]);
        }else{
    
        $this->load->view('Resp/DataCheck');
        }
    }

    public function payed()
    {
        $this->db->set ($_GET['f'], $_GET['v']);
        $this->db->where('id_pesanan', $_GET['id']);
        $this->db->update('pemesanan');

        redirect($_SERVER['HTTP_REFERER']);
    }
}
