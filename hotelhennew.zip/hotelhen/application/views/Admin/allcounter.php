<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Kamar Hotel</title>
  </head>
  <body>
    <!-- Navbar -->
    <div class="hello">
        <i class="hello"><span>Halo, <?=$_SESSION['user']->nama ?> </span></i>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">HotelHen</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?=base_url('/Admin/data?t=f_hotel&v=allcounter')?>">Fasilitas Hotel</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?=base_url('/Admin/data?t=f_kamar&v=allcounter')?>">Fasilitas Kamar</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?=base_url('/Admin/data?t=tipe_room&v=allcounter')?>">Tipe Kamar</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?=base_url('/Auth/logout')?>">Logout</a>
      </li>
    </ul>
  </div>
</nav>
    <!-- Navbar -->
    <?php $i=0; foreach ($data[0] as $key => $value){
    if ($i==0){
        $primary=$key;
    }
    $i++;
}?>
<div class="text-center">
    <a href="<?=base_url('admin/add'.$_GET['t']);?>" class="btn btn-primary"> Tambah Data</a>
</div>
<div class="card-table-responsive">
    <table class="table">
        <thead>
            <tr>
                <?php foreach($data[0] as $key => $value):?>
                    <th scope="col"><?=$key?></th>
                    <?php endforeach ?> 
                    <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $key => $value):?>
                <?php $i=0;?>
                <tr>
                    <?php foreach ($value as $key2 => $value2):?>
                        <?php if($i==0):?>
                        <form method="POST" action="<?=base_url('/admin/update?link='.$key2.'&val='. $value2.'&t='.$_GET['t'])?>">
                    <?php $i++; endif;?>
                    <th scope="col">
                        <input type="text" name="<?=$key2?>" class="form-control" value="<?=$value2?>">
                    </th>
                    <?php endforeach?>
                    <th scope="col">
                        <button type="sub" class="btn btn-primary">Update</button>

                    </th>
                </form>
                </tr>
                <?php endforeach ?>
        </tbody>
    </table>
</div>


