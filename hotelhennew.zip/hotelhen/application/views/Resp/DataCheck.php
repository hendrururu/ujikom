<div class="container" >
<div class="card mb-3">
                <img src="https://p4.wallpaperbetter.com/wallpaper/5/469/274/luxury-hotel-room-wallpaper-preview.jpg">
                <div class="card-body">
                    <h2 class="card-title">Cari Data</h2>
                    <p class="card-text">Masukkan Kode Booking :
                    <form action="<?=base_url('Resp/DataCheck') ?>" method="get" >
                <input type="text" name="ref" class="form-control">
                <button type="submit" class="btn btn-primary col-md-12 mt-2">
                    Cari
                </button>
                </form>
                </p>
                </div>
</div>
<div class="card mb-3">
                <img src="">
                <div class="card-body">
                    <h2 class="card-title">Tampilkan Semua Data?</h2>
                    <a href="<?=base_url('/Resp/call?t=pemesanan')?>" 
    class="btn btn-primary">Semua Data
  </a>
                </div>
</div>
</div>