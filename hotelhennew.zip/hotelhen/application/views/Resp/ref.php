<div class="card mb-3">
  <div class="card-body">
    <h5 class="card-title">List Booking :</h5>
    <p>
        <div class="row">
            <?php $data['booklah'] = array_reverse($data['booklah']);
            foreach($data['booklah'] as $key => $item ) : ?>
            <div class="col-md-4 mb-2">
                 <div class="card">
                <img src="">
                <div class="card-body">
                    <h5 class="card-title"><?=$item->Nama_room?> x <?=$item->jml_kamar ?> Kamar</h5>
                    <p>Nama tamu = <?=$item->nama_tamu?></p>
                    <p>Tanggal Check-In = <?=$item->tgl_cekin?></p>
                    <p>Tanggal Check-out = <?=$item->tgl_cekout?></p>
                    <p>Metode Pembayaran = <?=$item->PayBay?></p>
                    <p>
                      <?php if ($item->PayEND==0)
                      {$pesan= 'Pembayaran Belum Selesai';}
                      else {$pesan= 'Pembayaran Telah Selesai';}
                      echo $pesan;
                      ?>

                    </p>
                    <p>
                      <strong> 
                        ID Pemesanan Anda : <?=$item->RefPB?>
                      </strong>
                    </p>
                    <?php if ($item->PayEND==0)?>
                        <a href="<?=base_url ('Resp/payed?id=').$item->id_pesanan. '&f=PayEnd&v=1' ?>"
                        class="btn btn-warning"
                        >Bayar</a>
                        <?else:?>

                            <?php if (date('Y-m-d')>=$item->tgl_cekin&&date('Y-m-d')
                            <=$item->tgl_cekout) : ?>

                            <?php if($item->Status_Kamar=="CheckIn"): ?>
                                <p class="text-primary">
                                    Sudah Melakukan Check-In. 
                                    Silakan Lakukan Check-Out Pada Tanggal <?=$item->tgl_cekout?>
                                </p>
                                <?else ?>
                                <a href="<?=base_url ('Resp/payed?id=').$item->id_pesanan. '&f=Status_Kamar&v=CheckIn' ?>"
                        class="btn btn-warning"
                        >Check In</a>

                        <?php endif ?>

                        <?elseif (date('Y-m-d')==$item->tgl_cekout : ?>
                        <a href="<?=base_url ('Resp/payed?id=').$item->id_pesanan. '&f=Status_Kamar&v=CheckOut' ?>"
                        class="btn btn-warning"
                        >Check Out</a>
                        
                        <?elseif (date('Y-m-d')>$item->tgl_cekout : ?>
                            <p class="text-danger"> Terlambat Check Out</p>
                            <?php endif;?>
                            
                </div>      
            </div>
        </div>  
        <?php endforeach ?>
    </div>    
    </p>

    <div class="container" >
<div class="card mb-3">
                <img src="">
                <div class="card-body">
                    <h5 class="card-title">Cari Data</h5>
                    <p class="card-text">Masukkan Kode Booking :
                    <form action="<?=base_url('Resp/DataCheck') ?>" method="get" >
                <input type="text" name="ref" class="form-control">
                <button type="submit" class="btn btn-primary col-md-12 mt-2">
                    Cari
                </button>
                </form>
                </p>
                </div>
</div>

</div>