<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print</title>
</head>
<body>
<div class="card mb-3">
  <div class="card-body">
    <h5 class="card-title">List Bookinganmu : </h5>
    <p>
        <div class="row">
            <?php foreach($data['booklah'] as $key => $item ) : ?>
            <div class="col-md-4 mb-2">
                 <div class="card">
                 <img src="<?=$item->img_room ?>" class="card-img-top" alt="<?=$item->img_room ?>">
                <div class="card-body">
                    <h5 class="card-title"><?=$item->Nama_room?> x <?=$item->jml_kamar ?> Kamar</h5>
                    <p>Nama tamu = <?=$item->nama_tamu?></p>
                    <p>Tanggal Check-In = <?=$item->tgl_cekin?></p>
                    <p>Tanggal Check-out = <?=$item->tgl_cekout?></p>
                    <p>Metode Pembayaran = <?=$item->PayBay?></p>
                    <p>
                      <?php if ($item->PayEND==0)
                      {$pesan= 'Pembayaran Belum Selesai';}
                      else {$pesan= 'Pembayaran Telah Selesai';}
                      echo $pesan;
                      ?>

                    </p>
                    <p>
                      <strong> 
                        ID Pemesanan Anda : <?=$item->RefPB?>
                      </strong>
                    </p>
                </div>      
            </div>
        </div>  
        <?php endforeach ?>
    </div>    
    </p>
  </div>
</div>
     
     </div>
     <script type="text/javascript">
         window.print();
     </script>
</body>
</html>