<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
</head>
<body>
    <form method ="POST" action= "<?= base_url('/Auth/cekusers')?>"> 
    <input type="text" name="username" placeholder="Masukkan Username">
    <input type="password" name="password" placeholder="Masukkan Password">
    <button type="submit"> Login </button>
</form>
</body>
</html>